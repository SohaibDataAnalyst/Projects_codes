import requests as rq
from bs4 import BeautifulSoup
import pandas as pd

# Free CSS websites
Names_of_website_templates_free = []
Links_of_website_free = []
links_of_images_free = []

for i in range(1, 294):
    if i >= 2:
        url = 'https://www.free-css.com/free-css-templates?start=' + str((i - 1) * 12)
    else:
        url = 'https://www.free-css.com/free-css-templates'
    
    # Send GET request and retrieve web content
    web = rq.get(url)
    web_content = web.content
    soup = BeautifulSoup(web_content, 'html.parser')
    
    # Extract template names
    name_elements = soup.find_all(class_='name')
    for element in name_elements:
        Names_of_website_templates_free.append(element.text)
    
    # Extract template links
    a_tags = soup.select('li > figure > a')
    for a_tag in a_tags:
        Links_of_website_free.append("https://www.free-css.com" + a_tag['href'])
    
    # Extract image links
    img_tags = soup.select('div > ul > li > figure > a > img')
    for img_tag in img_tags:
        links_of_images_free.append("https://www.free-css.com" + img_tag['src'])

# Premium CSS websites
Names_of_website_templates_premium = []
Links_of_website_premium = []
links_of_images_premium = []

for i in range(1, 2):
    if i >= 2:
        url = 'https://www.free-css.com/free-css-templates?start=' + str((i - 1) * 12)
    else:
        url = 'https://www.free-css.com/commercial-templates'
    
    # Send GET request and retrieve web content
    web = rq.get(url)
    web_content = web.content
    soup = BeautifulSoup(web_content, 'html.parser')
    
    # Extract template names
    name_elements = soup.find_all(class_='name')
    for element in name_elements:
        Names_of_website_templates_premium.append(element.text)
    
    # Extract template links
    a_tags = soup.select('li > figure > a')
    for a_tag in a_tags:
        Links_of_website_premium.append(a_tag['href'])
    
    # Extract image links
    img_tags = soup.select('div > ul > li > figure > a > img')
    for img_tag in img_tags:
        links_of_images_premium.append("https://www.free-css.com" + img_tag['src'])

# Free CSS layout
Names_of_website_templates_layout = []
Links_of_website_free_layout = []
links_of_images_free_layout = []

for i in range(1, 23):
    url = 'https://www.free-css.com/free-css-layouts/page' + str(i)
    
    # Send GET request and retrieve web content
    web = rq.get(url)
    web_content = web.content
    soup = BeautifulSoup(web_content, 'html.parser')
    
    # Extract template names
    name_elements = soup.find_all(class_='name')
    for element in name_elements:
        Names_of_website_templates_layout.append(element.text)
    
    # Extract template links
    a_tags = soup.select('li > figure > a')
    for a_tag in a_tags:
        Links_of_website_free_layout.append("https://www.free-css.com" + a_tag['href'])
    
    # Extract image links
    img_tags = soup.select('div > ul > li > figure > a > img')
    for img_tag in img_tags:
        links_of_images_free_layout.append("https://www.free-css.com" + img_tag['src'])

# Free CSS menus
Menu_name = []
Menu_link = []
Menu_img = []

for i in range(1, 6):
    url = 'https://www.free-css.com/free-css-menus/page' + str(i)
    
    # Send GET request and retrieve web content
    web = rq.get(url)
    web_content = web.content
    soup = BeautifulSoup(web_content, 'html.parser')
    
    # Extract menu names
    name_elements = soup.find_all(class_='name')
    for element in name_elements:
        Menu_name.append(element.text)
    
    # Extract menu image links
    img_elements = soup.find_all(class_='screen')
    for img_element in img_elements:
        img_link = img_element.find('img')
        Menu_img.append("https://www.free-css.com" + img_link['src'])
    
    # Extract menu links
    link_elements = soup.find_all(class_='dld')
    for link_element in link_elements:
        link = link_element.find('a')
        Menu_link.append("https://www.free-css.com" + link['href'])

# Create dataframes
df_CSS_free = {'Names of free CSS website templates': Names_of_website_templates_free,
               'Links_of_website_free': Links_of_website_free,
               'links_of_images_free': links_of_images_free}

df_CSS_premium = {'Names_of_website_templates_premium': Names_of_website_templates_premium,
                  'Links_of_website_premium': Links_of_website_premium,
                  'links_of_images_premium': links_of_images_premium}

df_CSS_layout = {'Names_of_website_templates_layout': Names_of_website_templates_layout,
                 'Links_of_website_free_layout': Links_of_website_free_layout,
                 'links_of_images_free_layout': links_of_images_free_layout}

df_CSS_menu = {'Menu_name': Menu_name,
               'Menu_link': Menu_link,
               'Menu_img': Menu_img}

data1 = pd.DataFrame(df_CSS_free)
data2 = pd.DataFrame(df_CSS_premium)
data3 = pd.DataFrame(df_CSS_layout)
data4 = pd.DataFrame(df_CSS_menu)

# Save data to CSV files
data1.to_csv('data1.csv')
data2.to_csv('data2.csv')
data3.to_csv('data3.csv')
data4.to_csv('data4.csv')


# Print message after data extraction
print("Data extraction and saving to CSV files completed.")
